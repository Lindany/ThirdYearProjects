package Puzzle_Problem;

import java.lang.reflect.Array;


public class Board_Array {

	
	
	public static void main(String[] args) {
	
		LinkedList<Array> child_list = new LinkedList<>(); //Child List
		
		int [][] myboard_original = {{1,2,3},
									 {8,0,4},
									 {7,6,5}}; //Initialise Original Array
		
		System.out.println(checkpossibleMoves(myboard_original)); //Check move functions
		System.out.println(checkOutOfPlace(myboard_original)); //Check move functions
	
	}
	


	static public String checkpossibleMoves(int [][] myboard_original){
		int num_of_moves=0,Row=0,Col=0;
		
		while(myboard_original[Row][Col]!=0){
			if (Col<2) Col++;
			else{
				Col=0;
				Row++;
			}
		}
		
		if (!(Row-1 <0)) num_of_moves++;
		if (!(Col-1 <0)) num_of_moves++;
		if (!(Row+1 >2)) num_of_moves++;
		if (!(Col+1 >2)) num_of_moves++;
		
		return Row+"-"+Col+"-"+num_of_moves; 
	}
	
	static public int checkOutOfPlace(int [][] myboard_original){
		int count=0;
		
		if(myboard_original[0][0]!=1) count++;
		if(myboard_original[0][1]!=2) count++;
		if(myboard_original[0][2]!=3) count++;
		if(myboard_original[1][0]!=8) count++;
		if(myboard_original[1][1]!=0) count++;
		if(myboard_original[1][2]!=4) count++;
		if(myboard_original[2][0]!=7) count++;
		if(myboard_original[2][1]!=6) count++;
		if(myboard_original[2][2]!=5) count++;
		
		return count;
	}
}


package Puzzle_Problem;

public class LinkedList<T> {

}

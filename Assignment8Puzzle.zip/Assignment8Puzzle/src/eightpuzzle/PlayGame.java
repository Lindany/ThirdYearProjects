package eightpuzzle;
//lindani Ricardo Mabaso
//215016957

import java.sql.Array;
import java.util.*;
import java.util.zip.CheckedOutputStream;

public class PlayGame {
	/**
	 * Given an initial configuration and a goal configuration,
	 *  the 8-puzzle problem involves re-arranging the tiles in an
	 *	initial configuration to obtain a goal configuration. 
	 *	A legal move is moving any tile into the blank space except that
	 *	a tile may not move diagonally into the blank space i.e. 
	 *	a tile may be moved up, down, left or right into the blankspace.
	 * @param args
	 */
	
	static final int [][] goal_state =  {{1,2,3}, //Goal state
										{8,0,4},
										{7,6,5}};
	
	public static void main(String [] args){
		LinkedList<int[][]> lst_child, lst_open, lst_closed = new LinkedList<>();
		
		final int [][] init_state = {{2,8,1}, //Initial state
									 {4,6,3},
									 {0,7,5}};
		
		/**
		 * 1)checkpotentialChild()
		 * 2)tilesnotinPlace() // heuristicValue
		 * 3)selectChild
		 * 4)generateChildrens()
		 * 5)reversalSort()
		 * 6)isGoal()
		 * 7)display()
		 * 8)**DepthFirst, BreadthFirst, A*algorithm. (Implement)
		 * 9)Generate solution path.
		 * 10)Calculate heuristic value for A*algorithm.
		 */
		
		System.out.println("DFS");
		DepthFirst.depthfirstsearch(init_state,goal_state);
		//System.out.println("BFS");
		//BreadthFirst.breadfirstsearch(init_state,goal_state);
		System.out.println("A* Algoritm");
		AstarAlgorith.astarAlgorithtsearch(init_state, init_state);
	}
	
}

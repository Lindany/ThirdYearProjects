package eightpuzzle;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JRadioButton;
import java.awt.TextArea;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Panel;
import javax.swing.JTextField;
import javax.swing.JTextArea;

public class Puzzle_8Tiles {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Puzzle_8Tiles window = new Puzzle_8Tiles();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Puzzle_8Tiles() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 405);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblTilePuzzle = new JLabel("8 Tile Puzzle");
		lblTilePuzzle.setBounds(163, 5, 95, 15);
		frame.getContentPane().add(lblTilePuzzle);
		
		Panel panel = new Panel();
		panel.setBounds(298, 192, 117, 157);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(12, 48, 88, 25);
		panel.add(btnSearch);
		
		JButton btnClear = new JButton("Clear");
		btnClear.setBounds(12, 85, 88, 25);
		panel.add(btnClear);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(12, 119, 88, 25);
		panel.add(btnExit);
		
		textField = new JTextField();
		textField.setBounds(28, 145, 248, 204);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		Panel panel_1 = new Panel();
		panel_1.setBounds(28, 26, 212, 102);
		frame.getContentPane().add(panel_1);
		
		JRadioButton rdbtnBreadthFirstSearch = new JRadioButton("Breadth First Search");
		panel_1.add(rdbtnBreadthFirstSearch);
		
		JRadioButton DFS = new JRadioButton("Depth First Search");
		panel_1.add(DFS);
		
		JRadioButton rdbtnAAlgorithmSearch = new JRadioButton("A* Algorithm Search");
		panel_1.add(rdbtnAAlgorithmSearch);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(349, 133, 1, 15);
		frame.getContentPane().add(textArea_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(301, 57, 114, 19);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(301, 131, 114, 19);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblInitialState = new JLabel("Initial State");
		lblInitialState.setBounds(301, 26, 114, 15);
		frame.getContentPane().add(lblInitialState);
		
		JLabel lblFinalState = new JLabel("Final State");
		lblFinalState.setBounds(304, 106, 95, 15);
		frame.getContentPane().add(lblFinalState);
	}
}

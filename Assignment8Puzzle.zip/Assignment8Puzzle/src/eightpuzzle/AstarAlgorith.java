package eightpuzzle;
//Lindani Ricardo mabaso
//215016957

import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

public class AstarAlgorith {
	static final int [][] goal_state =  {{1,2,3}, //Goal state
										{8,0,4},
										{7,6,5}};

	public static void astarAlgorithtsearch(int[][]init_state,int[][]goal_state){
		/**
		 * This is the A*algorithm compute and display results
		 * @param init_state, final_state
		 * @return void
		 */
		
		Queue<int[][]> 		lst_child 	= new LinkedList<>(),
							lst_open 	= new LinkedList<>(),
							lst_closed 	= new LinkedList<>();
		int count=0;
		lst_open.add(init_state);
		boolean isSuccess = false;
		
		while(!lst_open.isEmpty() && !isSuccess){
			count++;
			int [][] x_array = lst_open.poll();
			x_array = reversalSort(x_array);
			if(isGoal(x_array)){
				isSuccess=true;
				System.out.println("\nCongratulations! You've Reached Final State\n"+count);
				arr_display(x_array);
			}
			else{
				lst_child = generateChildren(x_array);
				display(lst_child);
				
				//x_array  = 
				arr_display(x_array);
				lst_closed.add(x_array);
				lst_open.addAll(lst_child);
				lst_child.clear();
			}
		}
		
		
		
	}

	static public String checkpotentialChild(int [][] current_stage){
		/**
		 * This function checks how many possible moves / tiles can be moved.
		 * @param : ArrayList of that stage
		 * @return : String [Row-Col-NumberOfMoves]
		 */
		
		int num_of_moves=0, row=0, col=0;
		
		while(current_stage[row][col]!=0 &&row<=2){
			if(col<2) col++;
			else{
				col=0; row++;
			}
		}
		
		if(!(row-1 <0)) num_of_moves++;
		if(!(row+1 >2)) num_of_moves++;
		if(!(col-1 <0)) num_of_moves++;
		if(!(col+1 >2)) num_of_moves++;
		
		return row+""+col+""+num_of_moves;
	}
	
	static public int tilesoutOfPlace(int [][] current_state){
		/**
		 * This function returns heuristic value, tiles away to goal state.
		 * [returns zero if it is a goal state]
		 * @param : Array of current state and goal state
		 * @return : int, number of tiles not in place
		 */
		
		int tiles_count = 0;
		
		if(current_state[0][0]!=goal_state[0][0]) tiles_count++;
		if(current_state[0][1]!=goal_state[0][1]) tiles_count++;
		if(current_state[0][2]!=goal_state[0][2]) tiles_count++;
		if(current_state[1][0]!=goal_state[1][0]) tiles_count++;
		if(current_state[1][1]!=goal_state[1][1]) tiles_count++;
		if(current_state[1][2]!=goal_state[1][2]) tiles_count++;
		if(current_state[2][0]!=goal_state[2][0]) tiles_count++;
		if(current_state[2][1]!=goal_state[2][1]) tiles_count++;
		if(current_state[2][2]!=goal_state[2][2]) tiles_count++;
		
		return tiles_count;
	}
	
	static public LinkedList<int[][]> generateChildren(int [][] current_state){
		/**
		 * Generate children
		 * 
		 * @param : Array of current state array
		 * @return : List of children
		 */
		
		LinkedList<int[][]> children_lst = new LinkedList<>();
		int [][] a_child ,b_child ,c_child,d_child;
		int row, col;
		String output = checkpotentialChild(current_state);
		
		row = Integer.parseInt(output.charAt(0)+"");
		col = Integer.parseInt(output.charAt(1)+"");
		
		a_child = copyArray(current_state);
		b_child = copyArray(current_state);
		c_child = copyArray(current_state);
		d_child = copyArray(current_state);
		
		if(!(row-1 <0)){
			a_child[row][col] = a_child[row-1][col];
			a_child[row-1][col] = 0;
			children_lst.add(a_child);
		}
		if(!(row+1 >2)){
			b_child[row][col] = b_child[row+1][col];
			b_child[row+1][col] = 0;
			children_lst.add(b_child);
		}
		if(!(col-1 <0)){
			c_child[row][col] = c_child[row][col-1];
			c_child[row][col-1] = 0;
			children_lst.add(c_child);
		}
		if(!(col+1 >2)){
			d_child[row][col] = d_child[row][col+1];
			d_child[row][col+1] = 0;
			children_lst.add(d_child);
		}
		
		return children_lst;
	}
	
	static public int[][] getCurrentNode(Queue<int[][]> child_lst){

		/**
		 * Takes the list of children and compute the children with the lowest heuristic value(A* algorithm)
		 * Or select the child on the leftmost for DFS and BFS
		 * @param : child_list
		 * @return : array of a child
		 */
		int[][] qArr = child_lst.poll();
		int hValue,heuristicValue = tilesoutOfPlace(qArr);
		int [][] arr_current=qArr;
		child_lst.add(qArr);
		for(int i=1; i<child_lst.size(); i++){
			qArr = child_lst.poll();
			hValue = tilesoutOfPlace(qArr);
			if(hValue<heuristicValue){
				arr_current=qArr; //assign position of the desired array
			}
			child_lst.add(qArr);
		}
		return arr_current;
	}
	
	static public int[][] reversalSort(int[][]src){
		/**
		 * Checks for every adjacent values to swap
		 * @param : Array of current state and goal state
		 * @return : int [][] reversed/swapped array
		 */
		 int 	a1=src[0][0], a2=src[0][1], a3=src[0][2],
				a4=src[1][0], a5=src[1][1], a6=src[1][2],
				a7=src[2][0], a8=src[2][1], a9=src[2][2];
		 
		 int 	b1=goal_state[0][0], b2=goal_state[0][1], b3=goal_state[0][2],
				b4=goal_state[1][0], b5=goal_state[1][1], b6=goal_state[1][2],
				b7=goal_state[2][0], b8=goal_state[2][1], b9=goal_state[2][2];
		 
		 //Horizontal Check
		 if(a1==b2 && b1==a2) {a1=a2; a2=b2;}
		 if(a2==b3 && b2==a3) {a2=a3; a3=b3;}
		 if(a4==b5 && b4==a5) {a4=a5; a5=b5;}
		 if(a5==b6 && b5==a6) {a5=a6; a6=b6;}
		 if(a7==b8 && b7==a8) {a7=a8; a8=b8;}
		 if(a8==b9 && b8==a9) {a8=a9; a9=b9;}
		 
		 //Vertical Check
		 if(a1==b4 && b1==a4) {a1=a4; a4=b4;}
		 if(a4==b7 && b4==a7) {a4=a7; a7=b7;}
		 if(a2==b5 && b2==a5) {a2=a5; a5=b5;}
		 if(a5==b8 && b5==a8) {a5=a8; a8=b8;}
		 if(a3==b6 && b3==a6) {a3=a6; a6=b6;}
		 if(a6==b9 && b6==a9) {a6=a9; a9=b9;}
		 
		 int [][] arr_result= {{a1,a2,a3},{a4,a5,a6},{a7,a8,a9}};
		 return arr_result;

	}
	
	static public void display(Queue<int[][]> child_lst){
		/**
		 * Display arrays within a Linkedlist
		 * @param : LinkedList
		 * @return : void
		 */
		System.out.println("\nGroup");
		for(int i=0;i<child_lst.size();i++){
			int [][] arr_current =child_lst.poll();
			for(int row=0; row<3; row++){
				for(int col=0;col<3;col++){
					if(col!=0){
						System.out.print(" | "+arr_current[row][col]);
					} else
						System.out.print(arr_current[row][col]);
				}
				System.out.println("");
				
			}System.out.println("\n");
			child_lst.add(arr_current);
		}
		
	}
	
	static public void arr_display(int[][]arr_lst){
		/**
		 * Display arrays within a Linkedlist
		 * @param : LinkedList
		 * @return : void
		*/
		//System.out.println("Parent");
		for(int row=0; row<3; row++){
			for(int col=0;col<3;col++){
				if(col!=0){
					System.out.print(" | "+arr_lst[row][col]);
				} else
					System.out.print(arr_lst[row][col]);
			}
			System.out.println("");
		}
	}
			
	static public boolean isGoal(int [][] current_state){
		/**
		 * Checks if the state is really a final state(heuristic value==0)
		 * @param : Array of current state 
		 * @return : boolean
		 */
		if(tilesoutOfPlace(current_state)!=0)  return false;
		return true;
	}
	
	static public int[][] copyArray(int[][]src){
		/**
		 * makes a shallow copy
		 * @param : source[][] 
		 * @return : dst[][]
		 */
		int [][] dst = src.clone();
		for(int i=0; i<dst.length;i++) dst[i] = dst[i].clone();
		return dst;
	}
}
